# neo4j-wdc-node

## Summary
This project creates a docker container to allow for hosting the Tableau web data connector using node express.  Also included are endpoints for monitoring and management of the application, based on Spring Actuator.

## Setup (locally)
- docker build -t neo4j-wdc-node .
- docker run -p 8088:8088 neo4j-wdc-node

### Neo4j WDC Connector
- http://localhost:8088/website/Neo4jWdc2.html 

### Actuator Endpoints
- http://localhost:8088/management/info 
- http://localhost:8088/management/health

### Dependencies
- https://www.npmjs.com/package/express-actuator