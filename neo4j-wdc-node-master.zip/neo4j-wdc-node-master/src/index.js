'use strict';

const express = require('express');
const actuator = require('express-actuator');

const app = express();

//ACTUATOR
const options = {
    basePath: '/management', 
    infoGitMode: 'simple' 
};
app.use(actuator(options));

//STATIC WDC WEB CONTENT
app.use('/website', express.static('website'));

// Constants
const PORT = 8088;
const HOST = '0.0.0.0';

app.listen(PORT, HOST);
console.log(`Running on http://${HOST}:${PORT}`);
